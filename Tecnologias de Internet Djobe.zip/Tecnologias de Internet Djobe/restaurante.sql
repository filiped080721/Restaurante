-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 15/11/2024 às 17:06
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `restaurante`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `bebidas`
--

CREATE TABLE `bebidas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `tamanho` varchar(50) DEFAULT NULL,
  `disponivel` tinyint(1) DEFAULT 1,
  `imagem_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `bebidas`
--

INSERT INTO `bebidas` (`id`, `nome`, `descricao`, `preco`, `tamanho`, `disponivel`, `imagem_url`) VALUES
(1, 'Coca-Cola', 'Refrigerante clássico de cola', 5.00, '350ml', 1, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTmG_5ay6aNWHjNIQkGKxXp-k5_Z96_heVlQ&s'),
(2, 'Suco de Laranja', 'Suco natural feito com laranjas frescas', 7.50, '300ml', 1, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWs0P4VAujjagd8K0Hej9pbHiAuLIMz7xI4w&s'),
(3, 'Água Mineral', 'Água mineral sem gás', 2.50, '500ml', 1, 'https://vipspar.com/wp-content/uploads/2023/08/46142.jpg'),
(4, 'Chá Gelado', 'Chá gelado com sabor de limão', 6.00, '400ml', 1, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUdhGwCZvsRfUSBJDMaUBTDRa-ED9ENp64NA&s'),
(5, 'Cerveja Artesanal', 'Cerveja artesanal de trigo', 10.00, '500ml', 1, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4J_F4r-t5Gun77QQbEQCmXiofz3xTlWI2Ng&s');

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL,
  `nome_cliente` varchar(100) DEFAULT NULL,
  `comentario` text NOT NULL,
  `nota` int(11) DEFAULT NULL CHECK (`nota` >= 1 and `nota` <= 5),
  `data_comentario` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `comentarios`
--

INSERT INTO `comentarios` (`id`, `nome_cliente`, `comentario`, `nota`, `data_comentario`) VALUES
(1, 'Fernando Langa', 'A Matapa estava deliciosa, recomendo a todos!', 5, '2024-11-14 10:42:28'),
(2, 'Joana Santos', 'O Frango à Zambeziana é um dos melhores que já provei, mas o serviço poderia ser mais rápido.', 4, '2024-11-14 10:42:28'),
(3, 'Filipe Joaquim Daniel', 'Boa comida Estao de Parabens\r\n', 5, '2024-11-15 09:25:53'),
(4, 'Joana', 'Recomendo', 5, '2024-11-15 10:23:28'),
(5, 'Miguel Junior Portugal', 'Podiam melhorar um pouco o tempo de atendimento dos clientes,\r\nrecomendo ', 4, '2024-11-15 10:30:28'),
(6, 'Maria da Costa Pereira', 'Boa comida, Estão de Parabéns', 5, '2024-11-15 11:15:08'),
(7, 'Miguel Junior Portugal', 'Boa', 4, '2024-11-15 11:17:19'),
(8, 'Miguel Junior Portugal', 'Tempo de atendimento, deve ser melhorado', 5, '2024-11-15 11:18:38'),
(9, 'Maria da Costa Pereira', 'Boa', 5, '2024-11-15 11:21:44'),
(10, 'Joana Mateus de Lurdes', 'Good', 5, '2024-11-15 11:23:59'),
(11, 'Luis Mateus Manhangalane', 'Bom atendimento, Boa comida e bom Ambiente', 4, '2024-11-15 11:31:45'),
(12, 'Joana Mateus de Lurdes', 'good', 4, '2024-11-15 11:34:04'),
(13, 'Maria da Costa Pereira', 'Muito bom, muito Bom', 5, '2024-11-15 12:45:56'),
(14, 'Filipe Joaquim Daniel', 'Muito boa comida', 4, '2024-11-15 15:59:06');

-- --------------------------------------------------------

--
-- Estrutura para tabela `lanches`
--

CREATE TABLE `lanches` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `disponivel` tinyint(1) DEFAULT 1,
  `imagem_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `lanches`
--

INSERT INTO `lanches` (`id`, `nome`, `descricao`, `preco`, `tipo`, `disponivel`, `imagem_url`) VALUES
(1, 'Hambúrguer Clássico', 'Pão, hambúrguer de carne bovina, alface, tomate, queijo e molho especial', 15.00, 'Sanduíche', 1, 'https://img.freepik.com/fotos-premium/closeup-de-hamburguer-classico-com-hamburguer-de-carne-na-placa-de-madeira_219193-4702.jpg'),
(2, 'Cheeseburger', 'Hambúrguer de carne bovina com queijo cheddar derretido', 17.50, 'Sanduíche', 1, 'https://www.recipetineats.com/tachyon/2022/08/Stack-of-cheeseburgers.jpg'),
(3, 'Hot Dog Completo', 'Pão, salsicha, purê de batata, vinagrete, milho e batata palha', 12.00, 'Cachorro-Quente', 1, 'https://www.perdigao.com.br/assets/_images/306533a15c0257236ee24750b47d523e786523fd.webp'),
(4, 'Batata Frita', 'Batatas fritas crocantes servidas com ketchup', 8.00, 'Acompanhamento', 1, 'https://static.itdg.com.br/images/1200-630/16976699d08c8e6cd92db601741e0038/353026-original.jpg'),
(5, 'Salada Caesar', 'Salada com alface, frango grelhado, croutons e molho Caesar', 14.00, 'Salada', 1, 'https://marolacomcarambola.com.br/wp-content/uploads/2019/08/Receita-de-Salada-Caesar-Caesar-Salad-1.jpg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pratos`
--

CREATE TABLE `pratos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `disponivel` tinyint(1) DEFAULT 1,
  `imagem_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pratos`
--

INSERT INTO `pratos` (`id`, `nome`, `descricao`, `preco`, `categoria`, `disponivel`, `imagem_url`) VALUES
(1, 'Matapa', 'Prato tradicional moçambicano feito de folhas de mandioca cozidas com amendoim e leite de coco, servido com arroz.', 250.00, 'Tradicional', 1, 'https://www.diarioeconomico.co.mz/wp-content/uploads/2022/06/matapa_Easy-Resize.com_.jpg'),
(2, 'Frango à Zambeziana', 'Frango grelhado temperado com limão, alho, e leite de coco, típico da região da Zambézia.', 400.00, 'Grelhados', 1, 'https://www.mmo.co.mz/wp-content/uploads/2013/03/frango-a-zambeziana.jpg'),
(3, 'Camarão ao alho', 'Camarão grelhado com alho e especiarias locais, servido com batatas fritas ou arroz.', 550.00, 'Marisco', 1, 'https://static.itdg.com.br/images/1200-675/1c01a01db2f3f5e78197de84d6ee1dba/326210-original.jpg'),
(4, 'Xima', 'Purê de farinha de milho, comum em Moçambique, geralmente servido como acompanhamento.', 150.00, 'Acompanhamento', 1, 'https://i.ytimg.com/vi/H-OryXOhklc/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBCMlCMMFDdMjJgOaL-FMN8Jhzrug'),
(5, 'Caril de Amendoim', 'Caril rico e cremoso feito com pasta de amendoim e especiarias, servido com arroz.', 300.00, 'Tradicional', 1, 'https://i.ytimg.com/vi/XYXBwupYd0c/maxresdefault.jpg'),
(6, 'Feijão e Arroz', 'Comida Tipica de Mocabique', 250.00, 'Comida', 1, 'https://www.saboresajinomoto.com.br/uploads/images/recipes/arroz-e-feijao.jpg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `nome_cliente` varchar(100) NOT NULL,
  `telefone_cliente` varchar(15) NOT NULL,
  `email_cliente` varchar(100) DEFAULT NULL,
  `data_reserva` date NOT NULL,
  `hora_reserva` time NOT NULL,
  `numero_pessoas` int(11) NOT NULL CHECK (`numero_pessoas` > 0),
  `observacoes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `reservas`
--

INSERT INTO `reservas` (`id`, `nome_cliente`, `telefone_cliente`, `email_cliente`, `data_reserva`, `hora_reserva`, `numero_pessoas`, `observacoes`) VALUES
(1, 'Carlos Machel', '843567890', 'carlos.machel@example.com', '2024-11-22', '22:00:00', 4, 'Mesa perto da janela, se possível.'),
(4, 'Miguel Junior Portugal', '84596542', 'filipedanielljo57@gmail.com', '2024-11-28', '15:10:00', 5, 'Sem Pedido especial'),
(5, 'Miguelito Bruno da Costa', '258845993412', 'miguelitobruno@gmail.com', '2024-11-20', '15:00:00', 3, 'Sem pedidos'),
(8, 'Maria da Costa Pereira', '865974325', 'filipedanielljo57@gmail.com', '2024-11-20', '18:45:00', 7, 'Nada'),
(9, 'Maria da Costa Pereira', '847596412', 'maria.pereira43@gmail.com', '2024-11-18', '19:00:00', 10, 'Sem pedido');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `bebidas`
--
ALTER TABLE `bebidas`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `lanches`
--
ALTER TABLE `lanches`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pratos`
--
ALTER TABLE `pratos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bebidas`
--
ALTER TABLE `bebidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `lanches`
--
ALTER TABLE `lanches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `pratos`
--
ALTER TABLE `pratos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
