const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Configuração do body-parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Configuração da conexão com o banco de dados MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // substitua pelo seu usuário MySQL
    password: '', // substitua pela sua senha MySQL
    database: 'restaurante' // substitua pelo nome do seu banco de dados
});

// Conexão com o banco de dados
db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL!');
});

// Rota para a página principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Rota para visualizar os dados dos pratos
app.get('/pratos', (req, res) => {
    const sql = 'SELECT * FROM Pratos';
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar os pratos');
            return;
        }
        res.json(results);
    });
});

// Rota para visualizar os dados das promoções
app.get('/promocoes', (req, res) => {
    const sql = 'SELECT * FROM Promocoes';
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar as promoções');
            return;
        }
        res.json(results);
    });
});


// Rota para visualizar os dados das reservas
app.get('/reservas', (req, res) => {
    const sql = 'SELECT * FROM Reservas';
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar as reservas');
            return;
        }
        res.json(results);
    });
});



// Rota para visualizar os comentários
app.get('/comentarios', (req, res) => {
    const sql = 'SELECT * FROM Comentarios ORDER BY data_comentario DESC';
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar os comentários');
            return;
        }
        res.json(results);
    });
});
// Rota para inserir dados na tabela Comentarios
app.post('/comentarios', (req, res) => {
    const { nome_cliente, comentario, nota } = req.body;
    // Validação dos campos obrigatórios
    if (!nome_cliente || !comentario || !nota || nota < 1 || nota > 5) {
        res.status(400).send('Por favor, preencha todos os campos obrigatórios corretamente. A nota deve estar entre 1 e 5.');
        return;
    }

    // Inserção no banco de dados
    const sql = `
        INSERT INTO Comentarios 
        (nome_cliente, comentario, nota) 
        VALUES (?, ?, ?)
    `;
    db.query(sql, [nome_cliente, comentario, nota], (err, result) => {
        if (err) {
            console.error('Erro ao inserir comentário:', err);
            res.status(500).send('Erro ao inserir comentário. Tente novamente mais tarde.');
            return;
        }
        res.send('Comentário adicionado com sucesso!');
    });
});

// Rota para inserir dados na tabela Reservas
app.post('/reservas', (req, res) => {
    const { nome_cliente, telefone_cliente, email_cliente, data_reserva, hora_reserva, numero_pessoas, observacoes } = req.body;

    // Validação dos campos obrigatórios
    if (!nome_cliente || !telefone_cliente || !data_reserva || !hora_reserva || !numero_pessoas || numero_pessoas < 1) {
        res.status(400).send('Por favor, preencha todos os campos obrigatórios corretamente.');
        return;
    }

    if (email_cliente && !/\S+@\S+\.\S+/.test(email_cliente)) {
        res.status(400).send('Por favor, forneça um endereço de e-mail válido.');
        return;
    }

    // Inserção no banco de dados
    const sql = `
        INSERT INTO Reservas 
        (nome_cliente, telefone_cliente, email_cliente, data_reserva, hora_reserva, numero_pessoas, observacoes) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    db.query(sql, [nome_cliente, telefone_cliente, email_cliente, data_reserva, hora_reserva, numero_pessoas, observacoes], (err, result) => {
        if (err) {
            console.error('Erro ao inserir reserva:', err);
            res.status(500).send('Erro ao inserir reserva. Tente novamente mais tarde.');
            return;
        }
        res.send('Reserva feita com sucesso!');
    });
});

app.get('/verificar-reserva', (req, res) => {
    const { telefone_cliente } = req.query;

    if (!telefone_cliente) {
        res.status(400).send('Por favor, forneça um número de telefone.');
        return;
    }

    const sql = `
        SELECT * FROM Reservas 
        WHERE telefone_cliente = ? 
        AND data_reserva >= CURDATE()
    `;

    db.query(sql, [telefone_cliente], (err, results) => {
        if (err) {
            res.status(500).send('Erro ao verificar a reserva. Tente novamente mais tarde.');
            return;
        }

        res.json({
            existeReserva: results.length > 0,
            reservas: results
        });
    });
});

 // Atualizar a reserva no banco de dados

app.put('/editar-reserva', (req, res) => {
    const { id, nome_cliente, telefone_cliente, email_cliente, data_reserva, hora_reserva, numero_pessoas, observacoes } = req.body;

    // Verificando se todos os campos obrigatórios foram passados
    if (!id || !nome_cliente || !telefone_cliente || !data_reserva || !hora_reserva || !numero_pessoas || numero_pessoas < 1) {
        res.status(400).send('Por favor, preencha todos os campos obrigatórios corretamente.');
        return;
    }

    // Atualizar a reserva no banco de dados
    const sql = `
        UPDATE Reservas 
        SET nome_cliente = ?, telefone_cliente = ?, email_cliente = ?, data_reserva = ?, hora_reserva = ?, numero_pessoas = ?, observacoes = ?
        WHERE id = ?
    `;
    db.query(sql, [nome_cliente, telefone_cliente, email_cliente, data_reserva, hora_reserva, numero_pessoas, observacoes, id], (err, result) => {
        if (err) {
            res.status(500).send('Erro ao editar a reserva.');
            return;
        }
        res.send('Reserva atualizada com sucesso!');
    });
});


// Rota para cancelar reserva
app.delete('/cancelar-reserva', (req, res) => {
    const { id } = req.query; // Usando req.query para obter o id
    if (!id) {
        res.status(400).send('ID da reserva é necessário.');
        return;
    }

    const sql = 'DELETE FROM Reservas WHERE id = ?';
    db.query(sql, [id], (err) => {
        if (err) {
            res.status(500).send('Erro ao cancelar a reserva.');
            return;
        }

        res.send('Reserva cancelada com sucesso.');
    });
});

app.get('/bebidas', (req, res) => {
    const sql = 'SELECT * FROM Bebidas';
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar as bebidas');
            return;
        }
        res.json(results);
    });
});
app.get('/lanches', (req, res) => {
    const sql = 'SELECT * FROM Lanches';
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar os Lanches');
            return;
        }
        res.json(results);
    });
});
// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});


// Rota para adicionar um prato
app.post('/adicionar-prato', (req, res) => {
    const { nome, descricao, preco, categoria, disponivel, imagem_url } = req.body;
    const sql = 'INSERT INTO Pratos (nome, descricao, preco, categoria, disponivel, imagem_url) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(sql, [nome, descricao, preco, categoria, disponivel, imagem_url], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao adicionar prato.');
        }
        res.send('Prato adicionado com sucesso!');
    });
});

// Rota para adicionar uma bebida
app.post('/adicionar-bebida', (req, res) => {
    const { nome, descricao, preco, categoria, disponivel, imagem_url } = req.body;
    const sql = 'INSERT INTO Bebidas (nome, descricao, preco, categoria, disponivel, imagem_url) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(sql, [nome, descricao, preco, categoria, disponivel, imagem_url], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao adicionar bebida.');
        }
        res.send('Bebida adicionada com sucesso!');
    });
});

// Rota para adicionar um lanche
app.post('/adicionar-lanche', (req, res) => {
    const { nome, descricao, preco, categoria, disponivel, imagem_url } = req.body;
    const sql = 'INSERT INTO Lanches (nome, descricao, preco, categoria, disponivel, imagem_url) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(sql, [nome, descricao, preco, categoria, disponivel, imagem_url], (err, result) => {
        if (err) {
            return res.status(500).send('Erro ao adicionar lanche.');
        }
        res.send('Lanche adicionado com sucesso!');
    });
});

// Rota para listar todas as reservas
app.get('/listar-reservas', (req, res) => {
    const sql = 'SELECT * FROM Reservas ORDER BY data_reserva DESC';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).send('Erro ao listar reservas.');
        }
        res.json(results);
    });
});

app.get('/listar-produtos', (req, res) => {
    const { categoria, disponivel } = req.query;

    let sql = '';
    let params = [];

    // Se categoria for especificada, usa uma tabela específica, se não, junta todas
    if (categoria === 'Prato') {
        sql = 'SELECT * FROM Pratos WHERE 1=1';
    } else if (categoria === 'Bebida') {
        sql = 'SELECT * FROM Bebidas WHERE 1=1';
    } else if (categoria === 'Lanche') {
        sql = 'SELECT * FROM Lanches WHERE 1=1';
    } else {
        // Retorna todos os produtos se nenhuma categoria for especificada
        sql = '(SELECT * FROM Pratos UNION ALL SELECT * FROM Bebidas UNION ALL SELECT * FROM Lanches) AS Produtos WHERE 1=1';
    }

    // Filtro de disponibilidade
    if (disponivel !== undefined) {
        sql += ' AND disponivel = ?';
        params.push(disponivel === 'true' ? 1 : 0); // Convertendo para 1 (verdadeiro) ou 0 (falso)
    }

    console.log('Query SQL:', sql);
    console.log('Parâmetros:', params);

    db.query(sql, params, (err, results) => {
        if (err) {
            console.error('Erro ao executar a query:', err);
            return res.status(500).send('Erro ao listar produtos.');
        }
        res.json(results); // Retorna os produtos encontrados
    });
});